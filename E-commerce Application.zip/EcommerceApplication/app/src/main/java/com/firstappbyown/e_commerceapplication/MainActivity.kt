package com.firstappbyown.e_commerceapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import androidx.fragment.app.commit
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.firstappbyown.e_commerceapplication.ProductFragment
import com.firstappbyown.e_commerceapplication.R
import com.firstappbyown.e_commerceapplication.RecyclerAdapter
import com.firstappbyown.e_commerceapplication.databinding.ActivityMainBinding
import com.google.android.material.navigation.NavigationBarView


class MainActivity : AppCompatActivity(), NavigationBarView.OnItemSelectedListener {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.bottomNav.setOnItemSelectedListener(this)


    }


    override fun onNavigationItemSelected(item: MenuItem): Boolean {

            supportFragmentManager.commit {
                replace(R.id.frame_product_content, ProductFragment())
            }



        return true
    }
}