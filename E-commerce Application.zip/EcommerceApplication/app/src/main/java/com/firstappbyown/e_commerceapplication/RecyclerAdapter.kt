package com.firstappbyown.e_commerceapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView


class RecyclerAdapter : RecyclerView.Adapter<RecyclerAdapter.ViewHolder>() {

    private var name = arrayOf(
        "Boat Rocker 450", "Boat Rocker 500", "Leaf", "Titan Black", "Titan Red",
        "Nikaon Stylish", "Fastrack"
    )

    private var price = arrayOf(1499, 1999, 2000, 3999, 1599, 4500, 2545)

    private var images = arrayOf(
        R.drawable.boat_rockerz_450,
        R.drawable.boat_rockerz_500,
        R.drawable.leaf,
        R.drawable.titan_black,
        R.drawable.titan_red,
        R.drawable.nikon_stylish,
        R.drawable.fastrack
    )


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v =
            LayoutInflater.from(parent.context).inflate(R.layout.activity_card_view, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount(): Int {
        return name.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.product_name.text = name[position]
        holder.product_price.text= price[position].toString()
        holder.product_image.setImageResource(images[position])
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var product_image: ImageView
        var product_name: TextView
        var product_price: TextView

        init {
            product_image = itemView.findViewById(R.id.image_view)
            product_name = itemView.findViewById(R.id.text_view_product_name)
            product_price= itemView.findViewById(R.id.text_view_price)
        }
    }

}